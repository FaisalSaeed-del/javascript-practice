// alert("Welcome to my Hood");
//  var a=5;
//  var b=6;
//  var c=a+b;
//  alert(c);

// var a="chat";
// var b="App";
// var c=a+b;
// alert(c);

// var a=5;
// var b=a++;
// alert(b);

// var a=5;
// var b="2000"
// var c= a+b;
// console.log(c);
 
// var x=5;
// var y=x++ + x + ++x + x++ + x;
// alert(y);

//prompt//
// var a=prompt("Enter your value", "value is ");
// var b= a+10;
// alert



var val1=prompt('Enter your first value')
var sign=prompt('Enter your operator')
var val2=prompt('Enter your Second value')


console.log(val1+sign+val2)

if(sign==='+'){
    alert((+val1)+(+val2))
}else if(sign==='-'){
    alert(val1-val2)
}else if(sign==='*'){
    alert(val1*val2)
}else if(sign==='/'){
    alert(val1/val2)
}